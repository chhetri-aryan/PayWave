<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PayWave</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>
<body>
    <div class="navbar bg-base-300 px-4 md:px-8">
        <div class="flex-1">
          <a href="/" class="btn btn-ghost text-xl">PayWave 🌊</a>
        </div>
        <div class="flex-none">
          <div class="dropdown dropdown-end">
            <div tabindex="0" role="button" class="btn btn-ghost btn-circle avatar online">
              <div class="w-10 rounded-full">
                <img
                  alt="Profile image"
                  src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.webp" />
              </div>
            </div>
            <ul tabindex="0" class="menu menu-sm dropdown-content cardcolor rounded-box z-10 mt-3 w-52 p-2 shadow bg-black">
              <li>
                <a class="justify-between">
                  Profile
                  <span class="badge">New</span>
                </a>
              </li>
              <li><a>Settings</a></li>
              <form action="<?php echo e(route('logout')); ?>" method="POST">
                  <li>
                    <?php echo csrf_field(); ?>
                    <button type="submit">Logout</button>
                  </li>
              </form>
            
            </ul>
          </div>
        </div>
      </div>
    
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html><?php /**PATH C:\Users\aryan\Desktop\Laravel Project\paywave\resources\views/nav.blade.php ENDPATH**/ ?>